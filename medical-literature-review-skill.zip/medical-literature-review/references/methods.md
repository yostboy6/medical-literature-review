# Formal review methods

Use for systematic reviews or statistical synthesis. Do not expand an ordinary narrative overview into a formal review without the user's intent.

## Protocol and search

Prespecify eligibility, critical outcomes/time points, effect measures, selection/extraction processes, appraisal and synthesis. Check current PROSPERO eligibility and timing rules; use an appropriate alternative repository when ineligible. Drafting a protocol is not registration. Preserve actual registration status/date. Apply question-specific Cochrane/JBI methods; diagnostic, prognostic, qualitative and network reviews need their own approaches.

Pair controlled vocabulary with text synonyms, translate database syntax and test sensitivity against known relevant studies. Including every PICO element may overrestrict retrieval. Examine the need for comparator/outcome blocks and full-text, human, language and date filters. Save original exports and deduplication history. Supplement with citation chasing and registries. A medical librarian can help review a publication search. Record unavailable databases and their implications.

## Extraction and appraisal

Retain reviewer identities, decisions, disagreements and resolutions. Pilot extraction and independently check consequential fields. Link secondary reports and overlapping cohorts to avoid counting patients twice. Existing reviews support context and citation chasing; do not pool their estimates alongside their underlying primary trials.

Record outcome definition, scale direction, units, denominator, time point, estimand and adjusted/unadjusted status. Preserve arm-level values when used and label derivations. Capture funding/conflicts where relevant. Preserve evidence locations, abstract-only status and missing information. Apply the appraisal tool's actual domain questions rather than a generic quality score. GRADE rationales concern risk of bias, inconsistency, indirectness, imprecision, publication bias and other applicable considerations across the evidence for each outcome.

## Pairwise meta-analysis

Check compatible questions, populations, designs, outcomes, time points and estimands. HR, RR and OR are not interchangeable. Verify continuous-outcome units and justify mean difference or standardized mean difference. Align effect direction.

Prespecify and justify the model and assumptions. Record effect/variance derivations, transformations, estimator, interval method and software versions. Handle multiarm, paired, cluster, repeated-measure and overlapping data appropriately. Resolve dependence before pooling. Plan missing-data and zero-event handling.

Execute inspectable code, such as R meta/metafor, or appropriate RevMan analyses. Save inputs, code, logs, individual effects, pooled estimate with interval, heterogeneity and forest plot. Include an appropriate prediction interval when informative. Independently check representative calculations. Label unavailable execution as unrun. Bias tests need adequate study numbers and assumptions; funnel asymmetry alone does not establish publication bias. Tie sensitivity analyses to meaningful decisions and avoid post hoc significance hunting. If pooling is unsuitable, give structured synthesis and reasons.

## Completion

Report actual coverage/date, missing full texts, who checked screening/data/appraisal, unresolved inputs, whether code ran, and deviations. Reconcile PRISMA record/report/study counts. Explain uncertainty and applicability without converting a review into individual treatment advice.
