# Research sources

Reviewed online 2026-10-11. Recheck current versions for new work. Reddit is workflow discussion, not methodological authority. No clinical treatment conclusion was derived from these sources.

1. Cochrane Chapter 4, searching/selection: https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current/chapter-04
2. Cochrane Chapter 5, data collection: https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current/chapter-05
3. Cochrane Chapter 10, statistical synthesis: https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current/chapter-10
4. Cochrane Chapter 12, other synthesis: https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current/chapter-12
5. Cochrane Chapter 15, interpretation: https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current/chapter-15
6. PRISMA 2020 reporting: https://www.prisma-statement.org/prisma-2020
7. PRISMA-S search reporting: https://www.prisma-statement.org/prisma-search
8. PRISMA-ScR scoping reviews: https://www.prisma-statement.org/scoping
9. PROSPERO registry; JavaScript-limited during inspection, exact current eligibility needs rechecking: https://www.crd.york.ac.uk/prospero/home
10. NLM PubMed search/export documentation: https://pubmed.ncbi.nlm.nih.gov/help/
11. RoB 2 developers: https://www.riskofbias.info/welcome/rob-2-0-tool
12. Risk-of-bias tool developers: https://www.riskofbias.info/
13. GRADE Working Group: https://www.gradeworkinggroup.org/
14. Cal Poly Pomona Library, review/matrix guidance: https://libguides.library.cpp.edu/lit-review
15. Official OpenAI project documentation: https://learn.chatgpt.com/docs/projects
16. Official OpenAI research/files documentation: https://learn.chatgpt.com/docs/use-chatgpt
17. Reddit, physician's GPT review workflow discussion: https://www.reddit.com/r/ChatGPTPro/comments/1lmhf97/medical_doctors_writing_systematic_review/
18. Reddit, paper organization and matrices: https://www.reddit.com/r/AskAcademia/comments/1fam9sn/when_researching_a_new_topic_what_methods_do_you/
19. Reddit, workload/citation concerns; product mentions not endorsed: https://www.reddit.com/r/AcademicPsychology/comments/1r3lbk1/is_literature_review_supposed_to_feel_this/
