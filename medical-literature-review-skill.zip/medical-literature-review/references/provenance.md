# Video and research provenance

Prepared 2026-10-11 from the supplied 48-second ScreenRecording_10-11-2026 15-14-46_1.MP4. Inspection used sampled screen frames and visible captions across the recording. This is a visual/caption summary, not a verified audio transcript. The visible repost account is bzab.pages; the underlying demonstrator and application were not independently identified.

## What the clip shows

- Approximately 0:16–0:22: extracting the same facts from each paper.
- 0:23–0:25: collecting studies in one folder and defining a template once.
- 0:26–0:30: a table with population, methods, main outcome and effect size across papers.
- 0:31–0:33: citations opening a source paper/page.
- 0:34–0:40: comparison of benefit across studies and populations.
- 0:41–0:45: related-paper discovery, with access labels on candidates.

The table shows “29 files in folder” and “20 unsupported.” The adaptation therefore records ingestion failures instead of treating every uploaded paper as processed. The table mixes designs and effect types, so it does not establish eligibility for pooling.

Easy-publication and time-saving statements are promotional claims, not validated outcomes. The clip does not visibly establish protocol registration, comprehensive searching, independent screening, risk-of-bias assessment, certainty assessment or executed statistical pooling. These additions come from the methods sources.

## Research choices

Official review guidance supplies the formal methods. University library guidance supports matrices and thematic synthesis. Reddit contributes practical source-organization ideas and reports concerns about invented references. Anecdotes do not establish tool performance or medical validity; product mentions were not treated as endorsements.

For ChatGPT, adapt the folder concept to a project with uploaded files and shared instructions. Do not promise local-folder access or exact-page click-through for every PDF. Verify actual access and citations. The analysis stage is conditional: a literature review need not include meta-analysis.
