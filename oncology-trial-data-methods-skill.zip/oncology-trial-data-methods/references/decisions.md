# Decisions to settle before live extraction

1. Define eligible gastrointestinal, lung, and lymphoma subtypes and any biomarker-specific indication boundaries; decide how baskets and mixed histologies map to drug–indication pairs.
2. Specify ORR response criteria (for example disease-specific criteria), assessment time point, evaluable population, monotherapy versus combination handling, and which of multiple early reports determines the first signal versus the "best-reported" ORR.
3. Reconcile the protocol's ORR ≥30% primary cohort with its <30% comparison stratum. Prespecify the sampling frame and sensitivity thresholds; exactly 40% belongs in the 30–40% stratum.
4. Define what evidence establishes phase 3 initiation, first patient in, primary completion, public readout, FDA indication match, and dates when registry fields disagree or change after the census. Preserve a dated snapshot.
5. Define outcome states, censoring, competing discontinuation, unavailable records, and whether a registered but never recruited phase 3 trial counts. No phase 3 by census is not automatically failure.
6. Agree on the search protocol, librarian review, database access, conference abstract handling, screening rules, and live PRISMA record/report/study counts before declaring a systematic search.
7. Lock the Group A and B variable dictionary, two independent human extractors, third adjudicator, disagreement log, 10% source audit, analysis plan, and protocol/registration status. AI prefill would be a method amendment, not a substitute for independent extraction.
8. Define prespecified financial extension endpoints, entity matching, event categories, inflation base year/index if relevant, exchange-rate source/date, and whether any quantitative financing analysis is justified. Do not imply investment return or a causal explanation for delay.
9. Decide whether any patient-months or "avoidable delay" endpoint is defensible. It needs comparator, population, availability, counterfactual, and uncertainty definitions plus protocol amendment before analysis.
10. Confirm IRB/institutional determination and data-sharing rules. A public-source design alone does not establish the local review outcome.
