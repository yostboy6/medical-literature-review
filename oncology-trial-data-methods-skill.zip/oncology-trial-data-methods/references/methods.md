# Project methods scaffold

## Design

Retrospective observational cohort of drug–indication pairs within gastrointestinal cancers, lung cancer, and lymphoma. First public human phase 1 or phase 1/2 efficacy report: 2016-01-01 to 2020-12-31. Fixed outcome census: 2025-12-31. These are project definitions from the existing protocol, subject to the decisions file. Record exact source snapshot dates; do not backfill later knowledge into census status.

Group A constructs and verifies the registry/FDA cohort, canonical drug and indication identifiers, phase 3 and FDA outcomes, covariates, dictionary, code, Methods and Results. Group B designs and logs PubMed and accessible conference searches, screens reports, identifies the first phase 1 signal, logs documented stall reasons, maintains PRISMA-style counts, and writes Introduction and Discussion. Coordinate on a frozen pair list, but maintain two independent human extractions per record and third-person adjudication. Audit at least 10% against the original sources. Record deviations and amendments.

## Evidence hierarchy and workflow

Search public ClinicalTrials.gov and accessible public trial registries, PubMed, publicly available conference abstracts, FDA records, and public sponsor/regulatory filings as relevant. Preserve exact query, date, filters, count, URL or export identifier, and access level. A query draft is not an executed search. Do not scrape restricted databases or use paywalled material without access. Assign stable report and trial IDs, deduplicate reports to studies and studies to drug–indication pairs, and preserve full-text exclusion reasons. Distinguish abstract-only from verified full text. Source each collected value with a resolvable identifier, quote or field, and page/table/section or registry field. Never fabricate a link or a missing value.

Use the blank CSV headers as an exchange format. A human-entered adjudicated `pairs.csv` is paired with `provenance.csv` containing one row for every nonempty value field, including explicit missingness. Preserve raw independent reviewer files and disagreement/adjudication records separately. The validator checks structural consistency but cannot substitute for source verification or human adjudication.

## Outcome interpretation

ORR is a percent with numerator and denominator retained. Primary high-signal threshold is ≥30%. Strata are <30%, 30–40% inclusive, and >40%; do not pool response rates across incompatible diseases, criteria, or populations. Phase 3 status as of census is `yes`, `no_identified`, or `unknown`; `no_identified` means no qualifying record found under the documented search, not biologic failure. A source-supported discontinuation reason may be coded separately; otherwise use `unknown_unreported`. Treat right censoring and competing risks in the prespecified analysis. Phase 3 readout and FDA outcomes are separately observed fields. Derive intervals using executable Python or R with reviewed inputs, not mental arithmetic or LLM estimates.

The source protocol includes suggested regression and time-to-event analyses; feasibility and model choices depend on the actual cohort, missingness, event counts, and locked protocol. No analysis, OSF registration, search, or IRB determination has occurred in this scaffold. Daraxonrasib's 2026 exemplar is ineligible for the 2016–2020 index and 2025 census; at most use it as clearly dated background after verification.
