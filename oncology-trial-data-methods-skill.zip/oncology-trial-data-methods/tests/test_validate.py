import copy
import csv
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from validate import FIN_FIELDS, PAIR_FIELDS, PROV_FIELDS, read_csv, validate  # noqa: E402


class ValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        base = ROOT / "examples" / "fictional"
        cls.pairs = read_csv(base / "pairs.csv", PAIR_FIELDS)
        cls.prov = read_csv(base / "provenance.csv", PROV_FIELDS)
        cls.fin = read_csv(base / "financial-events.csv", FIN_FIELDS)

    def check_mutation(self, field, value, fragment):
        pairs = copy.deepcopy(self.pairs)
        pairs[0][field] = value
        self.assertTrue(any(fragment in error for error in validate(pairs, self.prov)), fragment)

    def test_fictional_fixture_passes(self):
        self.assertEqual(validate(self.pairs, self.prov, self.fin), [])

    def test_outside_index_date_rejected(self):
        self.check_mutation("phase1_first_signal_date", "2026-01-01", "outside 2016-2020")

    def test_post_census_outcome_rejected(self):
        self.check_mutation("phase3_start_date", "2026-01-01", "after census")

    def test_duplicate_pair_rejected(self):
        pairs = copy.deepcopy(self.pairs)
        pairs.append(copy.deepcopy(pairs[0]))
        self.assertTrue(any("duplicate drug-indication" in error for error in validate(pairs, self.prov)))

    def test_zero_denominator_rejected(self):
        self.check_mutation("orr_denominator", "0", "denominator must be positive")

    def test_numerator_bounds_rejected(self):
        self.check_mutation("orr_numerator", "21", "numerator exceeds denominator")

    def test_blank_is_not_missing_token(self):
        self.check_mutation("response_criteria", "", "blank response_criteria")

    def test_missing_provenance_rejected(self):
        prov = [row for row in self.prov if not (row["pair_id"] == self.pairs[0]["pair_id"] and row["field"] == "orr_percent")]
        self.assertTrue(any("missing provenance for orr_percent" in error for error in validate(self.pairs, prov)))

    def test_financial_currency_rejected(self):
        fin = copy.deepcopy(self.fin)
        fin[0]["reported_currency"] = "dollars"
        self.assertTrue(any("amount requires ISO currency" in error for error in validate(self.pairs, self.prov, fin)))


if __name__ == "__main__":
    unittest.main()
