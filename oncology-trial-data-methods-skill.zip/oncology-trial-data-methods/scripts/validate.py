#!/usr/bin/env python3
"""Deterministic structural checks for adjudicated trial CSVs; no clinical verification."""

import csv
import re
import sys
from datetime import date
from pathlib import Path

MISSING = {"NR", "UNK", "NA"}
CENSUS = date(2025, 12, 31)
FIRST = date(2016, 1, 1)
LAST = date(2020, 12, 31)
PAIR_FIELDS = [
    "pair_id", "drug_name", "indication", "disease_group", "disease_subtype",
    "phase1_trial_id", "phase1_first_signal_date", "orr_numerator",
    "orr_denominator", "orr_percent", "response_criteria", "phase3_status",
    "phase3_trial_id", "phase3_start_date", "phase3_readout_date",
    "fda_status", "fda_approval_date", "stall_reason", "status_as_of",
]
PROV_FIELDS = [
    "pair_id", "field", "source_type", "source_id", "locator",
    "evidence_excerpt", "access_level", "reviewer_id", "checked_date",
]
FIN_FIELDS = [
    "event_id", "pair_id", "sponsor_entity", "event_type", "event_date",
    "reported_amount", "reported_currency", "source_id", "locator",
    "evidence_excerpt", "publication_date", "access_level", "notes",
]


def read_csv(path, expected):
    with Path(path).open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != expected:
            raise ValueError("{}: headers differ from template".format(path))
        return list(reader)


def checked_date(value, label, errors):
    if value in MISSING:
        return None
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError):
        errors.append("{}: invalid ISO date".format(label))
        return None


def checked_int(value, label, errors):
    if value in MISSING:
        return None
    if not re.fullmatch(r"\d+", value or ""):
        errors.append("{}: expected nonnegative integer or explicit missing token".format(label))
        return None
    return int(value)


def validate(pairs, provenance, financial_events=None):
    errors = []
    ids = set()
    keys = set()
    for n, row in enumerate(pairs, 2):
        prefix = "pairs line {}".format(n)
        for field in PAIR_FIELDS:
            if row.get(field) is None or not row[field].strip():
                errors.append("{}: blank {} (use NR, UNK, or NA)".format(prefix, field))
        pair_id = row.get("pair_id", "")
        if pair_id in ids:
            errors.append("{}: duplicate pair_id {}".format(prefix, pair_id))
        ids.add(pair_id)
        key = (row.get("drug_name", "").casefold().strip(), row.get("indication", "").casefold().strip())
        if key in keys:
            errors.append("{}: duplicate drug-indication pair".format(prefix))
        keys.add(key)
        if row.get("disease_group") not in {"gastrointestinal", "lung", "lymphoma"}:
            errors.append("{}: invalid disease_group".format(prefix))
        signal = checked_date(row.get("phase1_first_signal_date"), prefix + " signal", errors)
        if signal and not FIRST <= signal <= LAST:
            errors.append("{}: signal outside 2016-2020 index".format(prefix))
        census = checked_date(row.get("status_as_of"), prefix + " status_as_of", errors)
        if census != CENSUS:
            errors.append("{}: status_as_of must be 2025-12-31".format(prefix))
        numerator = checked_int(row.get("orr_numerator"), prefix + " numerator", errors)
        denominator = checked_int(row.get("orr_denominator"), prefix + " denominator", errors)
        pct_value = row.get("orr_percent", "")
        pct = None
        if pct_value not in MISSING:
            try:
                pct = float(pct_value)
                if not 0 <= pct <= 100:
                    errors.append("{}: ORR percent outside 0-100".format(prefix))
            except (TypeError, ValueError):
                errors.append("{}: invalid ORR percent".format(prefix))
        if denominator is not None and denominator == 0:
            errors.append("{}: denominator must be positive".format(prefix))
        if numerator is not None and denominator is not None:
            if numerator > denominator:
                errors.append("{}: numerator exceeds denominator".format(prefix))
            if denominator > 0 and pct is not None and abs(pct - 100 * numerator / denominator) > 0.1:
                errors.append("{}: ORR percent disagrees with numerator/denominator".format(prefix))
        phase3 = row.get("phase3_status")
        if phase3 not in {"yes", "no_identified", "unknown"}:
            errors.append("{}: invalid phase3_status".format(prefix))
        start = checked_date(row.get("phase3_start_date"), prefix + " phase3_start", errors)
        readout = checked_date(row.get("phase3_readout_date"), prefix + " phase3_readout", errors)
        approval = checked_date(row.get("fda_approval_date"), prefix + " fda_approval", errors)
        if phase3 == "yes" and (not start or row.get("phase3_trial_id") in MISSING):
            errors.append("{}: phase3 yes requires trial ID and start date".format(prefix))
        if phase3 == "no_identified" and (start or readout):
            errors.append("{}: no_identified conflicts with phase3 dates".format(prefix))
        if start and signal and start < signal:
            errors.append("{}: phase3 start precedes public signal; adjudicate against protocol".format(prefix))
        if start and readout and readout < start:
            errors.append("{}: phase3 readout precedes start".format(prefix))
        for name, value in (("phase3_start", start), ("phase3_readout", readout), ("fda_approval", approval)):
            if value and value > CENSUS:
                errors.append("{}: {} after census".format(prefix, name))
        if row.get("fda_status") not in {"yes", "no_identified", "unknown"}:
            errors.append("{}: invalid fda_status".format(prefix))
        if row.get("fda_status") == "yes" and not approval:
            errors.append("{}: FDA yes requires approval date".format(prefix))
        if row.get("fda_status") == "no_identified" and approval:
            errors.append("{}: FDA no_identified conflicts with approval date".format(prefix))
        if row.get("stall_reason") not in {
            "toxicity_safety", "business_strategic", "sponsor_insolvency",
            "competitive_displacement", "other_documented", "unknown_unreported", "NA",
        }:
            errors.append("{}: invalid stall_reason".format(prefix))
        if phase3 == "yes" and row.get("stall_reason") != "NA":
            errors.append("{}: reached phase3; stall_reason should be NA".format(prefix))
    seen_prov = set()
    for n, row in enumerate(provenance, 2):
        prefix = "provenance line {}".format(n)
        for field in PROV_FIELDS:
            if row.get(field) is None or not row[field].strip():
                errors.append("{}: blank {}".format(prefix, field))
        if row.get("pair_id") not in ids:
            errors.append("{}: unknown pair_id".format(prefix))
        if row.get("field") not in PAIR_FIELDS[1:]:
            errors.append("{}: invalid field".format(prefix))
        seen_prov.add((row.get("pair_id"), row.get("field")))
        checked_date(row.get("checked_date"), prefix + " checked_date", errors)
    for row in pairs:
        for field in PAIR_FIELDS[1:]:
            if (row.get("pair_id"), field) not in seen_prov:
                errors.append("{}: missing provenance for {}".format(row.get("pair_id"), field))
    if financial_events is not None:
        event_ids = set()
        for n, row in enumerate(financial_events, 2):
            prefix = "financial line {}".format(n)
            for field in FIN_FIELDS:
                if row.get(field) is None or not row[field].strip():
                    errors.append("{}: blank {}".format(prefix, field))
            if row.get("event_id") in event_ids:
                errors.append("{}: duplicate event_id".format(prefix))
            event_ids.add(row.get("event_id"))
            if row.get("pair_id") not in ids:
                errors.append("{}: unknown pair_id".format(prefix))
            event_date = checked_date(row.get("event_date"), prefix + " event_date", errors)
            publication_date = checked_date(row.get("publication_date"), prefix + " publication_date", errors)
            if event_date and publication_date and publication_date < event_date:
                errors.append("{}: publication precedes event".format(prefix))
            amount = row.get("reported_amount")
            currency = row.get("reported_currency")
            if amount not in MISSING:
                try:
                    if float(amount) < 0:
                        errors.append("{}: negative amount".format(prefix))
                except (TypeError, ValueError):
                    errors.append("{}: invalid amount".format(prefix))
                if not re.fullmatch(r"[A-Z]{3}", currency or ""):
                    errors.append("{}: amount requires ISO currency".format(prefix))
    return errors


def main(argv):
    if len(argv) not in (3, 4):
        print("usage: validate.py PAIRS.csv PROVENANCE.csv [FINANCIAL.csv]", file=sys.stderr)
        return 2
    try:
        pairs = read_csv(argv[1], PAIR_FIELDS)
        provenance = read_csv(argv[2], PROV_FIELDS)
        financial = read_csv(argv[3], FIN_FIELDS) if len(argv) == 4 else None
    except (OSError, ValueError) as exc:
        print(exc, file=sys.stderr)
        return 2
    errors = validate(pairs, provenance, financial)
    if errors:
        for error in errors:
            print(error, file=sys.stderr)
        return 1
    print("Validation passed: {} pairs, {} provenance rows{}".format(
        len(pairs), len(provenance), ", {} financial events".format(len(financial)) if financial is not None else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
