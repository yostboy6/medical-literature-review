---
name: oncology-trial-data-methods
description: Help an oncology research team build an auditable drug-indication registry cohort, verify FDA and phase 3 outcomes, validate data, and prepare reproducible analysis, Methods and Results.
---

# Oncology trial data and methods

Support Group A's registry, data and statistics work. This is a workflow and validation toolkit, not a completed cohort or an automated registry collector. Read references/methods.md, references/data-dictionary.md and references/decisions.md before collecting data. Project settings require the team's approval; do not silently resolve open protocol choices.

## Four steps

1. **Set up.** Ask for the approved protocol, dictionary and current pair list. Confirm disease/biomarker boundaries, endpoints, date rules and reviewer assignments. Use assets/templates/ for blank CSVs. One row represents a drug–indication pair; preserve linked trial and report identifiers separately.
2. **Verify sources.** Draft and execute documented ClinicalTrials.gov and FDA searches using available authorized tools. Log actual query, retrieval date, result count and snapshot. Match indication, population and combination regimen. For every value save a source ID, exact field or short excerpt and locator in provenance.csv. Unrun searches and inaccessible sources remain explicitly pending.
3. **Reconcile and check.** Preserve two independent human extractions, third-person adjudication and a 10% original-source audit. AI is not an independent reviewer. Do not supply shared AI-prefilled answers before independent extraction without an approved method amendment. Once adjudicated, run `python3 scripts/validate.py pairs.csv provenance.csv`; inspect flags against sources. NR means not reported, UNK unresolved, NA not applicable; none is zero. Preserve partial/raw dates separately: the supplied validator accepts exact ISO dates or missing tokens, so never invent a day to make it pass.
4. **Analyze and hand off.** Freeze a versioned, adjudicated dataset. Draft executable R/Python code, then actually run it and retain inputs, environment, output and checks. Prepare descriptive tables and prespecified time-to-event/model analyses only if feasible and reviewed by the statistician. Distinguish planned analyses from executed results. Write Methods and Results with an evidence trail and a STROBE checklist.

## Project definitions

First public human phase 1/1–2 efficacy report: 2016-01-01 through 2020-12-31. Outcome census: 2025-12-31. Disease groups: gastrointestinal, lung and lymphoma, with subtype boundaries still requiring agreement. Primary high-signal cohort ORR ≥30%; strata <30%, 30–40% inclusive, >40%. Exactly 40% belongs in the middle group. The role of the <30% comparator is unresolved. Do not pool incompatible response criteria/populations.

Keep phase 3 initiation, primary completion, public readout and indication-matched FDA approval distinct. No identified phase 3 is not proof of failure. Preserve unknown status, ongoing/right censoring and documented discontinuation separately; use no post-census outcomes to rewrite census status. Group B supplies verified first-signal reports and documented stall reasons using the shared pair ID.

## Files and limits

assets/templates/ contains blank exchange sheets. examples/fictional/ contains synthetic test data, never study observations. scripts/validate.py checks structure and deterministic consistency, not source truth or clinical interpretation. Run its regression checks with `python3 -m unittest discover -s tests -v`. Financial files are an optional inherited extension and are outside the core Group A workflow. Do not claim OSF registration, IRB determination, collection counts or scientific findings from this toolkit. Keep private PDFs, reviewer files, personal contacts and live data out of public GitHub unless separately authorized.
